package danyizhize;
//��������ϵͳ
public class MainClass {
	String username;
	String password;
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
//	�޲ι���
	public MainClass() {
		super();
		// TODO Auto-generated constructor stub
	}
//�вι���
	public MainClass(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginForm.init();
		LoginForm.display();
		LoginForm.validate();
	}
	
	
}
